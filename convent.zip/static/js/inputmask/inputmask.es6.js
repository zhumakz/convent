// eslint-disable-next-line import/no-unresolved
import "./inputmask.js";

const inputmask = window.Inputmask;
window.Inputmask = undefined;
export default inputmask;
