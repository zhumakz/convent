def register_signals():
    import coins.signals  # Импортируем сигналы здесь

