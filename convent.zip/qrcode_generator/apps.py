from django.apps import AppConfig


class QrcodeGeneratorConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'qrcode_generator'
