const timer = new Timer(document.querySelector(".timer"));
timer.timerStart()